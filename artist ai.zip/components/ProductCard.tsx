import React from 'react';
import { Product } from '../types';
import { ShoppingBag, Eye } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onView, onAddToCart }) => {
  return (
    <div className="group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-brand-100 flex flex-col h-full">
      <div className="relative aspect-[3/4] overflow-hidden bg-brand-50">
        <img 
          src={product.imageUrl} 
          alt={product.title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <button 
            onClick={() => onView(product)}
            className="bg-white text-brand-900 px-4 py-2 rounded-full font-medium text-sm flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 shadow-lg"
          >
            <Eye size={16} /> View Details
          </button>
        </div>
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <div>
            <p className="text-xs text-brand-500 uppercase tracking-wide font-semibold">{product.category}</p>
            <h3 className="font-serif text-lg text-brand-900 leading-tight">{product.title}</h3>
          </div>
          <span className="font-medium text-brand-900">${product.price}</span>
        </div>
        <p className="text-sm text-brand-500 line-clamp-2 mb-4 flex-grow">{product.description}</p>
        <div className="flex items-center justify-between mt-auto pt-4 border-t border-brand-50">
          <span className="text-xs text-brand-400">By {product.designer}</span>
          <button 
            onClick={() => onAddToCart(product)}
            className="text-brand-900 hover:text-brand-600 transition-colors p-2 rounded-full hover:bg-brand-50"
            aria-label="Add to cart"
          >
            <ShoppingBag size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};