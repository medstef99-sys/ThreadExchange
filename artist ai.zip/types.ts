export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string;
  designer: string;
  category: 'Women' | 'Men' | 'Accessories' | 'Avant-Garde';
  tags: string[];
}

export interface CartItem extends Product {
  quantity: number;
}

export enum ViewState {
  MARKETPLACE = 'MARKETPLACE',
  SELLER_DASHBOARD = 'SELLER_DASHBOARD',
  PRODUCT_DETAIL = 'PRODUCT_DETAIL',
}

export interface SellerStat {
  name: string;
  sales: number;
  revenue: number;
}