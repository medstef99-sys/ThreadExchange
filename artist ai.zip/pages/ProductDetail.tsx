import React from 'react';
import { Product } from '../types';
import { ArrowLeft, ShoppingBag, Star, ShieldCheck, Truck } from 'lucide-react';

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
  onAddToCart: (product: Product) => void;
}

export const ProductDetail: React.FC<ProductDetailProps> = ({ product, onBack, onAddToCart }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-brand-500 hover:text-brand-900 mb-8 transition-colors group"
      >
        <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" /> Back to Collection
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
        {/* Image Gallery */}
        <div className="space-y-4">
          <div className="aspect-[3/4] bg-white rounded-xl overflow-hidden shadow-lg border border-brand-100">
            <img 
              src={product.imageUrl} 
              alt={product.title} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="grid grid-cols-4 gap-4">
             {/* Mock thumbnails */}
             {[...Array(4)].map((_, i) => (
                <div key={i} className="aspect-square bg-white rounded-lg overflow-hidden border border-brand-200 hover:border-brand-900 cursor-pointer opacity-70 hover:opacity-100 transition-all">
                    <img src={product.imageUrl} alt="thumb" className="w-full h-full object-cover" />
                </div>
             ))}
          </div>
        </div>

        {/* Info */}
        <div className="flex flex-col h-full justify-center">
          <div className="mb-2 flex items-center gap-2">
            <span className="px-3 py-1 bg-brand-100 text-brand-800 text-xs font-semibold uppercase tracking-wider rounded-full">
              {product.category}
            </span>
            {product.tags.slice(0, 1).map(tag => (
                 <span key={tag} className="px-3 py-1 bg-white border border-brand-200 text-brand-500 text-xs font-medium rounded-full">
                 #{tag}
               </span>
            ))}
          </div>
          
          <h1 className="text-4xl md:text-5xl font-serif text-brand-900 mb-4 leading-tight">
            {product.title}
          </h1>

          <div className="flex items-center gap-4 mb-6">
             <div className="flex text-yellow-500">
                {[...Array(5)].map((_,i) => <Star key={i} size={16} fill="currentColor" />)}
             </div>
             <span className="text-sm text-brand-400">(24 Reviews)</span>
          </div>
          
          <div className="text-3xl font-light text-brand-900 mb-8">
            ${product.price.toFixed(2)}
          </div>

          <p className="text-brand-600 text-lg leading-relaxed mb-8">
            {product.description}
          </p>

          <div className="space-y-4 mb-10">
            <div className="flex items-center gap-3 text-sm text-brand-500">
                <ShieldCheck size={18} className="text-brand-900" />
                <span>Authenticity Guaranteed by Atelier AI</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-brand-500">
                <Truck size={18} className="text-brand-900" />
                <span>Free Worldwide Shipping</span>
            </div>
          </div>

          <div className="flex gap-4">
            <button 
              onClick={() => onAddToCart(product)}
              className="flex-1 bg-brand-900 text-white py-4 rounded-xl font-medium text-lg hover:bg-brand-800 transition-all shadow-lg hover:shadow-xl active:scale-95 flex items-center justify-center gap-3"
            >
              <ShoppingBag size={20} /> Add to Bag
            </button>
            <button className="px-6 py-4 border border-brand-200 rounded-xl hover:bg-brand-50 transition-colors">
                 Like
            </button>
          </div>
          
          <p className="mt-8 text-xs text-brand-400">
            Designed by <span className="font-semibold text-brand-900">{product.designer}</span>.
          </p>
        </div>
      </div>
    </div>
  );
};