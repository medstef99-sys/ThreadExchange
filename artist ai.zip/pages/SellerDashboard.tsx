import React, { useState, useEffect, useCallback } from 'react';
import { Product } from '../types';
import { generateProductDescription, generateTrendAdvice } from '../services/geminiService';
import { Upload, Sparkles, DollarSign, Tag, Loader2, BarChart2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface SellerDashboardProps {
  onAddProduct: (product: Product) => void;
}

const MOCK_ANALYTICS = [
  { name: 'Jan', sales: 4000 },
  { name: 'Feb', sales: 3000 },
  { name: 'Mar', sales: 2000 },
  { name: 'Apr', sales: 2780 },
  { name: 'May', sales: 1890 },
  { name: 'Jun', sales: 2390 },
  { name: 'Jul', sales: 3490 },
];

export const SellerDashboard: React.FC<SellerDashboardProps> = ({ onAddProduct }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'create'>('create');
  
  // Form State
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('Women');
  const [description, setDescription] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [generatedTags, setGeneratedTags] = useState<string[]>([]);
  
  // AI State
  const [isGenerating, setIsGenerating] = useState(false);
  const [trendAdvice, setTrendAdvice] = useState<string>('');

  useEffect(() => {
    // Load trends on mount
    generateTrendAdvice().then(setTrendAdvice);
  }, []);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateAI = async () => {
    if (!imagePreview || !title) {
      alert("Please upload an image and provide a title first.");
      return;
    }
    setIsGenerating(true);
    try {
      const result = await generateProductDescription(imagePreview, title, category);
      setDescription(result.description);
      setGeneratedTags(result.tags);
    } catch (err) {
      console.error(err);
      alert("Failed to generate description.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !price || !imagePreview) return;

    const newProduct: Product = {
      id: Date.now().toString(),
      title,
      price: parseFloat(price),
      description: description || 'No description provided.',
      imageUrl: imagePreview,
      designer: 'Current User', // Mock user
      category: category as any,
      tags: generatedTags
    };

    onAddProduct(newProduct);
    alert('Product listed successfully!');
    // Reset form
    setTitle('');
    setPrice('');
    setDescription('');
    setImageFile(null);
    setImagePreview(null);
    setGeneratedTags([]);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="font-serif text-3xl text-brand-900">Seller Studio</h1>
          <p className="text-brand-500">Manage your designs and performance.</p>
        </div>
        <div className="bg-white rounded-lg p-1 bg-brand-100 flex">
          <button 
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'overview' ? 'bg-white shadow-sm text-brand-900' : 'text-brand-500 hover:text-brand-900'}`}
          >
            Overview
          </button>
          <button 
            onClick={() => setActiveTab('create')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'create' ? 'bg-white shadow-sm text-brand-900' : 'text-brand-500 hover:text-brand-900'}`}
          >
            New Listing
          </button>
        </div>
      </div>

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-brand-100">
            <h3 className="text-lg font-medium text-brand-900 mb-6 flex items-center gap-2">
              <BarChart2 size={20} /> Revenue Performance
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={MOCK_ANALYTICS}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                  <XAxis dataKey="name" tick={{fill: '#6b7280', fontSize: 12}} axisLine={false} tickLine={false} />
                  <YAxis tick={{fill: '#6b7280', fontSize: 12}} axisLine={false} tickLine={false} tickFormatter={(value) => `$${value}`} />
                  <Tooltip cursor={{fill: '#f3f4f6'}} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }} />
                  <Bar dataKey="sales" fill="#3f4652" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="bg-brand-900 text-white p-6 rounded-xl shadow-lg relative overflow-hidden">
             <div className="relative z-10">
                <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
                    <Sparkles size={18} className="text-yellow-400" /> AI Trend Forecast
                </h3>
                <div className="text-brand-100 text-sm leading-relaxed whitespace-pre-wrap">
                    {trendAdvice || "Loading market insights..."}
                </div>
             </div>
             <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
          </div>
        </div>
      )}

      {activeTab === 'create' && (
        <div className="bg-white rounded-xl shadow-sm border border-brand-100 overflow-hidden flex flex-col md:flex-row">
          {/* Image Upload Side */}
          <div className="md:w-1/3 bg-brand-50 p-8 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-brand-100">
            {imagePreview ? (
              <div className="relative w-full aspect-[3/4] rounded-lg overflow-hidden shadow-md">
                <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                <button 
                  onClick={() => { setImagePreview(null); setImageFile(null); }}
                  className="absolute top-2 right-2 bg-white/90 p-2 rounded-full text-red-500 hover:text-red-700 transition"
                >
                  <Upload size={16} className="rotate-45" />
                </button>
              </div>
            ) : (
              <label className="w-full h-64 border-2 border-dashed border-brand-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-brand-500 hover:bg-brand-100 transition-all group">
                <Upload className="h-10 w-10 text-brand-400 group-hover:text-brand-600 mb-2" />
                <span className="text-sm text-brand-500 font-medium">Upload Design</span>
                <span className="text-xs text-brand-400 mt-1">JPG, PNG up to 10MB</span>
                <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
              </label>
            )}
            <p className="mt-4 text-xs text-brand-400 text-center max-w-xs">
              High-quality images increase sales by 40%. Use natural lighting.
            </p>
          </div>

          {/* Form Side */}
          <div className="md:w-2/3 p-8">
            <h2 className="text-2xl font-serif text-brand-900 mb-6">Product Details</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-brand-700 mb-1">Product Title</label>
                  <input 
                    type="text" 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full border border-brand-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-800 focus:outline-none"
                    placeholder="e.g., Midnight Velvet Blazer"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-brand-700 mb-1">Price ($)</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-400" size={16} />
                    <input 
                      type="number" 
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="w-full border border-brand-200 rounded-lg pl-9 pr-4 py-2 focus:ring-2 focus:ring-brand-800 focus:outline-none"
                      placeholder="0.00"
                      required
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-brand-700 mb-1">Category</label>
                <select 
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full border border-brand-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-800 focus:outline-none bg-white"
                >
                  <option value="Women">Women</option>
                  <option value="Men">Men</option>
                  <option value="Accessories">Accessories</option>
                  <option value="Avant-Garde">Avant-Garde</option>
                </select>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-sm font-medium text-brand-700">Description</label>
                  <button 
                    type="button"
                    onClick={handleGenerateAI}
                    disabled={isGenerating || !imagePreview}
                    className="text-xs flex items-center gap-1 text-indigo-600 hover:text-indigo-800 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                  >
                    {isGenerating ? <Loader2 className="animate-spin h-3 w-3" /> : <Sparkles size={12} />}
                    {isGenerating ? "Magic working..." : "Auto-Generate with AI"}
                  </button>
                </div>
                <textarea 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="w-full border border-brand-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-800 focus:outline-none resize-none"
                  placeholder="Describe your masterpiece..."
                />
              </div>

              {generatedTags.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-brand-700 mb-2">Suggested Tags</label>
                  <div className="flex flex-wrap gap-2">
                    {generatedTags.map((tag, idx) => (
                      <span key={idx} className="bg-brand-100 text-brand-700 px-3 py-1 rounded-full text-xs flex items-center gap-1">
                        <Tag size={10} /> {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-4 border-t border-brand-100 flex justify-end">
                <button 
                  type="submit"
                  className="bg-brand-900 text-white px-8 py-3 rounded-lg font-medium hover:bg-brand-800 transition-colors shadow-lg hover:shadow-xl transform active:scale-95 duration-200"
                >
                  Publish Listing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};