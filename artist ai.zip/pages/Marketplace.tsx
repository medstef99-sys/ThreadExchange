import React, { useState } from 'react';
import { Product, ViewState } from '../types';
import { ProductCard } from '../components/ProductCard';
import { Filter, Search } from 'lucide-react';

interface MarketplaceProps {
  products: Product[];
  onViewProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const Marketplace: React.FC<MarketplaceProps> = ({ products, onViewProduct, onAddToCart }) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = ['All', 'Women', 'Men', 'Accessories', 'Avant-Garde'];

  const filteredProducts = products.filter(p => {
    const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.designer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header & Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-10 gap-6">
        <div>
          <h1 className="font-serif text-4xl text-brand-900 mb-2">New Arrivals</h1>
          <p className="text-brand-500">Curated designs from independent creators worldwide.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-400" size={18} />
                <input 
                    type="text" 
                    placeholder="Search designers..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-brand-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-800 bg-white text-sm w-full sm:w-64"
                />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
            {categories.map(cat => (
                <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                    activeCategory === cat 
                    ? 'bg-brand-900 text-white' 
                    : 'bg-white text-brand-600 border border-brand-200 hover:border-brand-400'
                }`}
                >
                {cat}
                </button>
            ))}
            </div>
        </div>
      </div>

      {/* Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProducts.map(product => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onView={onViewProduct} 
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-xl border border-dashed border-brand-200">
          <Filter className="mx-auto h-12 w-12 text-brand-300 mb-4" />
          <h3 className="text-lg font-medium text-brand-900">No products found</h3>
          <p className="text-brand-500">Try adjusting your search or filters.</p>
        </div>
      )}
    </div>
  );
};