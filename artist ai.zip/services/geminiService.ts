import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateProductDescription = async (
  imageBase64: string,
  title: string,
  category: string
): Promise<{ description: string; tags: string[] }> => {
  try {
    // Remove header if present (e.g., "data:image/jpeg;base64,")
    const base64Data = imageBase64.split(',')[1] || imageBase64;

    const prompt = `
      You are a high-end fashion copywriter for a luxury marketplace called "Atelier AI".
      Analyze the attached image of a clothing item.
      The item title is "${title}" and the category is "${category}".
      
      1. Write a compelling, sophisticated product description (max 100 words) highlighting material, style, and occasion.
      2. Generate 5 relevant hashtags/keywords for SEO.
      
      Return the response in JSON format:
      {
        "description": "...",
        "tags": ["tag1", "tag2", ...]
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg", // Assuming JPEG for simplicity, or detect from header
              data: base64Data
            }
          },
          {
            text: prompt
          }
        ]
      },
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      description: "A unique piece designed with precision and care. (AI generation failed, please edit manually)",
      tags: ["Fashion", "Design"]
    };
  }
};

export const generateTrendAdvice = async (): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: "Briefly describe the current top 3 fashion trends for avant-garde and streetwear designers for the upcoming season. Keep it concise (bullet points).",
        });
        return response.text || "Unable to fetch trends.";
    } catch (e) {
        return "Trend analysis unavailable.";
    }
}