import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useLocation, Link, Navigate } from 'react-router-dom';
import { Product, ViewState, CartItem } from './types';
import { Marketplace } from './pages/Marketplace';
import { SellerDashboard } from './pages/SellerDashboard';
import { ProductDetail } from './pages/ProductDetail';
import { ShoppingBag, User, PlusCircle, Search, Menu, X } from 'lucide-react';

// Seed Data
const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    title: 'Ethereal Silk Wrap Dress',
    description: 'Hand-dyed silk wrap dress featuring a fluid silhouette and minimalist aesthetic. Perfect for evening soirées.',
    price: 320,
    imageUrl: 'https://picsum.photos/600/800?random=1',
    designer: 'Elena V.',
    category: 'Women',
    tags: ['Silk', 'Evening', 'Minimalist']
  },
  {
    id: '2',
    title: 'Obsidian Structure Jacket',
    description: 'Avant-garde structured jacket with asymmetrical cuts and metallic hardware. A statement piece for the modern urbanite.',
    price: 550,
    imageUrl: 'https://picsum.photos/600/800?random=2',
    designer: 'Koji T.',
    category: 'Avant-Garde',
    tags: ['Techwear', 'Black', 'Structure']
  },
  {
    id: '3',
    title: 'Nomad Leather Weekender',
    description: 'Full-grain leather weekend bag crafted for durability and style. Features antique brass fittings and reinforced stitching.',
    price: 480,
    imageUrl: 'https://picsum.photos/600/800?random=3',
    designer: 'Studio North',
    category: 'Accessories',
    tags: ['Travel', 'Leather', 'Handmade']
  },
  {
    id: '4',
    title: 'Linen Pleated Trousers',
    description: 'Breathable linen trousers with a high-waisted fit and deep pleats. Effortless elegance for summer days.',
    price: 180,
    imageUrl: 'https://picsum.photos/600/800?random=4',
    designer: 'Maison Ciel',
    category: 'Men',
    tags: ['Summer', 'Linen', 'Casual']
  }
];

const Navbar: React.FC<{ cartCount: number, toggleMenu: () => void, isMenuOpen: boolean }> = ({ cartCount, toggleMenu, isMenuOpen }) => {
    return (
        <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-brand-100">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center h-20">
                    <Link to="/" className="flex items-center gap-2 group">
                        <div className="h-8 w-8 bg-brand-900 text-white flex items-center justify-center rounded-full font-serif font-bold text-xl group-hover:bg-brand-700 transition-colors">A</div>
                        <span className="font-serif text-2xl tracking-tight text-brand-950">Atelier AI</span>
                    </Link>

                    {/* Desktop Menu */}
                    <div className="hidden md:flex items-center space-x-8">
                        <Link to="/" className="text-brand-600 hover:text-brand-900 font-medium text-sm tracking-wide transition-colors">SHOP</Link>
                        <Link to="/sell" className="text-brand-600 hover:text-brand-900 font-medium text-sm tracking-wide transition-colors">SELL</Link>
                        <Link to="/" className="text-brand-600 hover:text-brand-900 font-medium text-sm tracking-wide transition-colors">DESIGNERS</Link>
                    </div>

                    <div className="hidden md:flex items-center space-x-6">
                        <button className="text-brand-900 hover:text-brand-600 transition">
                            <Search size={20} strokeWidth={1.5} />
                        </button>
                        <Link to="/sell" className="text-brand-900 hover:text-brand-600 transition" title="Seller Dashboard">
                             <User size={20} strokeWidth={1.5} />
                        </Link>
                        <div className="relative cursor-pointer group">
                             <ShoppingBag size={20} strokeWidth={1.5} className="text-brand-900 group-hover:text-brand-600 transition" />
                             {cartCount > 0 && (
                                <span className="absolute -top-2 -right-2 bg-brand-900 text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                                    {cartCount}
                                </span>
                             )}
                        </div>
                    </div>

                    {/* Mobile Menu Button */}
                    <button onClick={toggleMenu} className="md:hidden text-brand-900">
                        {isMenuOpen ? <X /> : <Menu />}
                    </button>
                </div>
            </div>

            {/* Mobile Menu */}
            {isMenuOpen && (
                <div className="md:hidden bg-white border-t border-brand-100 absolute w-full px-4 py-4 flex flex-col space-y-4 shadow-lg">
                    <Link to="/" onClick={toggleMenu} className="text-brand-900 font-medium">Shop</Link>
                    <Link to="/sell" onClick={toggleMenu} className="text-brand-900 font-medium">Sell Design</Link>
                    <div className="h-px bg-brand-100 w-full my-2"></div>
                    <div className="flex items-center justify-between">
                         <span className="text-brand-500">Cart ({cartCount})</span>
                         <ShoppingBag size={20} />
                    </div>
                </div>
            )}
        </nav>
    )
}

const AppContent: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Navigation State Helper (handled by Router mostly, but needed for Product Detail Modal/Page transition logic)
  const location = useLocation();

  const handleAddToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    // Add visual feedback (toast in real app)
    console.log(`Added ${product.title} to cart`);
  };

  const handleAddProduct = (newProduct: Product) => {
    setProducts([newProduct, ...products]);
  };

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-brand-50 flex flex-col">
       <Navbar 
          cartCount={cart.reduce((acc, item) => acc + item.quantity, 0)} 
          isMenuOpen={isMenuOpen}
          toggleMenu={() => setIsMenuOpen(!isMenuOpen)}
       />
      
       <main className="flex-grow">
        <Routes>
            <Route path="/" element={
                <Marketplace 
                    products={products} 
                    onViewProduct={(p) => {
                        setSelectedProduct(p);
                        // In a real router, we'd navigate to /product/:id
                        // For this SPA structure without complex URL params logic in `index.tsx`, we simulate via link wrapper
                    }} 
                    onAddToCart={handleAddToCart}
                />
            } />
             {/* Dynamic Route wrapper for Detail Page since we don't have id-based fetching logic hooked up to a DB */}
            <Route path="/product/:id" element={
                selectedProduct ? (
                    <ProductDetail 
                        product={selectedProduct} 
                        onBack={() => window.history.back()} 
                        onAddToCart={handleAddToCart} 
                    />
                ) : <Navigate to="/" />
            } />

            <Route path="/sell" element={
                <SellerDashboard onAddProduct={handleAddProduct} />
            } />
        </Routes>

        {/* Manual Routing Intercept for Product Click from Marketplace (Simulating navigation) */}
        {selectedProduct && location.pathname === '/' && (
            // This is a logic bridge. In a real app, ProductCard links to /product/:id.
            // Here we render nothing because we want the user to stay on /, 
            // but the Marketplace component handles the click.
            // Wait, better approach for this simplified code:
            // Let's make the ProductCard navigate programmatically.
            // Re-implementing the Routes to be cleaner.
            <Navigate to={`/product/${selectedProduct.id}`} />
        )}
       </main>

       <footer className="bg-brand-950 text-brand-300 py-12 border-t border-brand-900">
           <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
               <div>
                   <h2 className="text-white font-serif text-xl mb-4">Atelier AI</h2>
                   <p className="text-sm leading-relaxed">The future of fashion commerce. Powered by artificial intelligence, curated by humans.</p>
               </div>
               <div>
                   <h3 className="text-white font-medium mb-4">Shop</h3>
                   <ul className="space-y-2 text-sm">
                       <li><a href="#" className="hover:text-white transition">New Arrivals</a></li>
                       <li><a href="#" className="hover:text-white transition">Designers</a></li>
                       <li><a href="#" className="hover:text-white transition">Trending</a></li>
                   </ul>
               </div>
               <div>
                   <h3 className="text-white font-medium mb-4">Support</h3>
                   <ul className="space-y-2 text-sm">
                       <li><a href="#" className="hover:text-white transition">Shipping & Returns</a></li>
                       <li><a href="#" className="hover:text-white transition">Size Guide</a></li>
                       <li><a href="#" className="hover:text-white transition">Contact Us</a></li>
                   </ul>
               </div>
               <div>
                   <h3 className="text-white font-medium mb-4">Newsletter</h3>
                   <div className="flex">
                       <input type="email" placeholder="Your email" className="bg-brand-900 border-none text-white px-4 py-2 rounded-l-md focus:ring-1 focus:ring-white w-full text-sm" />
                       <button className="bg-white text-brand-950 px-4 py-2 rounded-r-md text-sm font-medium">Join</button>
                   </div>
               </div>
           </div>
           <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-brand-900 text-xs text-center text-brand-500">
               © {new Date().getFullYear()} Atelier AI. All rights reserved.
           </div>
       </footer>
    </div>
  );
};

const App: React.FC = () => {
    return (
        <HashRouter>
            <AppContent />
        </HashRouter>
    );
}

export default App;